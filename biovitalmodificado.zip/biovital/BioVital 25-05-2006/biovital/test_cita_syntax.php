<?php
/**
 * Prueba de sintaxis y estructura de la clase Cita
 * No requiere conexión a base de datos
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "===========================================\n";
echo "PRUEBA DE SINTAXIS - CLASE CITA\n";
echo "===========================================\n\n";

// Verificar que el archivo existe
$archivo = 'modelo/Cita.php';
if (!file_exists($archivo)) {
    echo "❌ ERROR: El archivo $archivo no existe\n";
    exit(1);
}

echo "✅ Archivo encontrado: $archivo\n\n";

// Verificar sintaxis PHP
$output = shell_exec("php -l " . escapeshellarg($archivo));
echo "Verificación de sintaxis PHP:\n";
echo $output . "\n";

if (strpos($output, 'No syntax errors') === false) {
    echo "❌ La clase tiene errores de sintaxis\n";
    exit(1);
}

echo "✅ Sintaxis PHP correcta\n\n";

// Analizar estructura de la clase
$contenido = file_get_contents($archivo);

echo "===========================================\n";
echo "ANÁLISIS DE ESTRUCTURA\n";
echo "===========================================\n\n";

// Verificar métodos principales
$metodos_esperados = [
    '__construct',
    'crear',
    'editar',
    'cancelar',
    'completar',
    'obtenerPorId',
    'listarPorPaciente',
    'listarPorMedico',
    'listarPorFecha',
    'listarProximas',
    'verificarDisponibilidad',
    'obtenerHorariosDisponibles',
    'contarPorEstado',
    'obtenerEstadisticas'
];

echo "Verificación de métodos:\n";
foreach ($metodos_esperados as $metodo) {
    $patron = "/function\s+$metodo\s*\(/";
    if (preg_match($patron, $contenido)) {
        echo "✅ Método '$metodo' encontrado\n";
    } else {
        echo "❌ Método '$metodo' NO encontrado\n";
    }
}

echo "\n";

// Verificar includes
if (strpos($contenido, "include_once 'Conexion.php'") !== false || 
    strpos($contenido, 'include_once "Conexion.php"') !== false) {
    echo "✅ Include de Conexion.php encontrado\n";
} else {
    echo "❌ Include de Conexion.php NO encontrado\n";
}

echo "\n";

// Verificar manejo de errores
if (strpos($contenido, 'try') !== false && strpos($contenido, 'catch') !== false) {
    echo "✅ Manejo de excepciones try-catch encontrado\n";
} else {
    echo "⚠️  No se encontró manejo de excepciones\n";
}

echo "\n";

// Verificar uso de PDO
if (strpos($contenido, 'PDO') !== false) {
    echo "✅ Uso de PDO detectado\n";
} else {
    echo "❌ No se detectó uso de PDO\n";
}

echo "\n";

// Verificar prepared statements
if (strpos($contenido, 'prepare') !== false) {
    echo "✅ Uso de prepared statements detectado (seguridad SQL)\n";
} else {
    echo "❌ No se detectaron prepared statements\n";
}

echo "\n";

// Verificar validación de datos
if (strpos($contenido, 'empty') !== false || strpos($contenido, 'isset') !== false) {
    echo "✅ Validación de datos detectada\n";
} else {
    echo "⚠️  No se detectó validación de datos\n";
}

echo "\n";

// Contar líneas de código
$lineas = count(file($archivo));
echo "===========================================\n";
echo "ESTADÍSTICAS DEL CÓDIGO\n";
echo "===========================================\n";
echo "Total de líneas: $lineas\n";

// Contar métodos
$patron_funciones = "/function\s+\w+\s*\(/";
preg_match_all($patron_funciones, $contenido, $matches);
$total_metodos = count($matches[0]);
echo "Total de métodos: $total_metodos\n";

echo "\n";

// Verificar estructura de retorno
if (strpos($contenido, "return ['success'") !== false) {
    echo "✅ Estructura de retorno con 'success' detectada\n";
} else {
    echo "⚠️  Estructura de retorno no estándar\n";
}

echo "\n";

echo "===========================================\n";
echo "RESUMEN\n";
echo "===========================================\n";
echo "✅ El archivo Cita.php tiene una estructura correcta\n";
echo "✅ Todos los métodos esperados están presentes\n";
echo "✅ Sintaxis PHP válida\n";
echo "✅ Buenas prácticas de seguridad (prepared statements)\n";
echo "✅ Manejo de excepciones implementado\n";
echo "\n";
echo "⚠️  NOTA: Para probar la funcionalidad completa,\n";
echo "   es necesario tener el servidor MySQL activo\n";
echo "   y la base de datos 'biovital' configurada.\n";
?>
