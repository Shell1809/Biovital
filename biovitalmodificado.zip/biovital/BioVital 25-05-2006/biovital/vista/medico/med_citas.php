<?php
// vista/medico/med_citas.php

if($_SESSION['us_tipo'] != 2 || $_SESSION['rol'] != 'medico'){
    header('Location: ' . APP_URL . '/login/medico');
    exit();
}

$nombre_usuario = $_SESSION['nombre_us'] ?? 'Usuario';
$id_medico = $_SESSION['usuario'];
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <script>
        var APP_URL = '<?php echo APP_URL; ?>';
        var ID_MEDICO = <?php echo json_encode($id_medico); ?>;
    </script>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="<?php echo APP_URL; ?>/js/config.js"></script>
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/css/css/all.min.css">
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/css/adminlte.min.css">
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/css/dashboard.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <title>Médico | Mis Citas</title>
    
    <style>
        .badge-programada { background-color: #007bff; color: white; padding: 5px 10px; border-radius: 20px; font-size: 11px; }
        .badge-completada { background-color: #28a745; color: white; padding: 5px 10px; border-radius: 20px; font-size: 11px; }
        .badge-cancelada { background-color: #dc3545; color: white; padding: 5px 10px; border-radius: 20px; font-size: 11px; }
    </style>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
    </ul>
    <ul class="navbar-nav ml-auto">
        <a href="<?php echo APP_URL; ?>/logout" class="btn btn-danger btn-sm">
            <i class="fas fa-sign-out-alt"></i> Cerrar sesión
        </a>
    </ul>
</nav>

<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="<?php echo APP_URL; ?>/panel/medico" class="brand-link">
        <img src="<?php echo APP_URL; ?>/img/logo_azul.png" alt="Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light">BioVital</span>
    </a>
    <div class="sidebar">
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img id="avatar4" src="<?php echo APP_URL; ?>/img/avatar.png" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info">
                <a href="#" class="d-block"><?php echo htmlspecialchars($nombre_usuario); ?></a>
            </div>
        </div>
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu">
                <li class="nav-header"><i class="fas fa-user-md"></i> Médico</li>
                <li class="nav-item">
                    <a href="<?php echo APP_URL; ?>/perfil" class="nav-link">
                        <i class="nav-icon fas fa-user-cog"></i>
                        <p>Datos personales</p>
                    </a>
                </li>
                <li class="nav-header"><i class="fas fa-calendar-alt"></i> Citas</li>
                <li class="nav-item">
                    <a href="<?php echo APP_URL; ?>/citas" class="nav-link active">
                        <i class="nav-icon fas fa-calendar-alt"></i>
                        <p>Mis Citas</p>
                    </a>
                </li>
                <li class="nav-header"><i class="fas fa-users"></i> Pacientes</li>
                <li class="nav-item">
                    <a href="<?php echo APP_URL; ?>/medico/pacientes" class="nav-link">
                        <i class="nav-icon fas fa-users"></i>
                        <p>Mis Pacientes</p>
                    </a>
                </li>
                <li class="nav-header"><i class="fas fa-prescription"></i> Recetas</li>
                <li class="nav-item">
                    <a href="<?php echo APP_URL; ?>/recetas" class="nav-link">
                        <i class="nav-icon fas fa-prescription-bottle-alt"></i>
                        <p>Gestionar Recetas</p>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</aside>

<!-- Content Wrapper -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><i class="fas fa-calendar-alt"></i> Agenda de Citas</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo APP_URL; ?>/panel/medico">Home</a></li>
                        <li class="breadcrumb-item active">Mis Citas</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            
            <!-- Welcome Banner -->
            <div class="bv-welcome-banner bv-animate">
                <h2><i class="fas fa-calendar-check"></i> Agenda de Citas</h2>
                <p>Consulta y gestiona las citas programadas con tus pacientes.</p>
                <div class="bv-role-tag"><i class="fas fa-user-md"></i> Médico</div>
            </div>

            <!-- Filtros -->
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label><i class="fas fa-calendar-alt"></i> Fecha</label>
                                        <input type="date" class="form-control" id="filtro_fecha" value="<?php echo date('Y-m-d'); ?>">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label><i class="fas fa-filter"></i> Estado</label>
                                        <select class="form-control" id="filtro_estado">
                                            <option value="">Todos</option>
                                            <option value="programada">Programada</option>
                                            <option value="completada">Completada</option>
                                            <option value="cancelada">Cancelada</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>&nbsp;</label>
                                        <button class="btn btn-primary btn-block" id="btnFiltrar">
                                            <i class="fas fa-search"></i> Filtrar
                                        </button>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>&nbsp;</label>
                                        <button class="btn btn-secondary btn-block" id="btnLimpiarFiltro">
                                            <i class="fas fa-times"></i> Limpiar
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Stats Cards -->
            <div class="row">
                <div class="col-md-3 col-sm-6 col-12">
                    <div class="info-box bv-animate bv-animate-delay-1">
                        <span class="info-box-icon bg-info"><i class="fas fa-calendar-alt"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Total Hoy</span>
                            <span class="info-box-number" id="total_hoy">0</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-12">
                    <div class="info-box bv-animate bv-animate-delay-2">
                        <span class="info-box-icon bg-success"><i class="fas fa-clock"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Programadas</span>
                            <span class="info-box-number" id="citas_programadas">0</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-12">
                    <div class="info-box bv-animate bv-animate-delay-3">
                        <span class="info-box-icon bg-primary"><i class="fas fa-check-circle"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Completadas</span>
                            <span class="info-box-number" id="citas_completadas">0</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-12">
                    <div class="info-box bv-animate bv-animate-delay-4">
                        <span class="info-box-icon bg-warning"><i class="fas fa-user-injured"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Pacientes Hoy</span>
                            <span class="info-box-number" id="pacientes_hoy">0</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tabla de Citas -->
            <div class="row mt-3">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fas fa-list"></i> Listado de Citas</h3>
                            <div class="card-tools">
                                <button class="btn btn-default btn-sm" id="btnRefresh">
                                    <i class="fas fa-sync-alt"></i> Actualizar
                                </button>
                            </div>
                        </div>
                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover text-nowrap">
                                <thead>
                                    <tr>
                                        <th>Hora</th>
                                        <th>Paciente</th>
                                        <th>Cédula</th>
                                        <th>Teléfono</th>
                                        <th>Motivo</th>
                                        <th>Estado</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody id="tabla_citas">
                                    <tr><td colspan="7" class="text-center">
                                        <div class="spinner-border text-primary" role="status">
                                            <span class="sr-only">Cargando...</span>
                                        </div>
                                        <p>Cargando citas...</p>
                                    </td></tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2024 BioVital.</strong> Todos los derechos reservados.
</footer>

</div>

<script src="<?php echo APP_URL; ?>/js/adminlte.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
$(document).ready(function() {
    cargarCitas();

    $('#btnRefresh, #btnFiltrar').click(function() {
        cargarCitas();
    });

    $('#btnLimpiarFiltro').click(function() {
        $('#filtro_fecha').val('<?php echo date('Y-m-d'); ?>');
        $('#filtro_estado').val('');
        cargarCitas();
    });

    function cargarCitas() {
        let fecha = $('#filtro_fecha').val();
        let estado = $('#filtro_estado').val();
        
        $('#tabla_citas').html('<tr><td colspan="7" class="text-center"><div class="spinner-border text-primary"></div><p>Cargando citas...</p></td></tr>');
        
        $.ajax({
            url: APP_URL + '/api/citas/medico',
            type: 'POST',
            data: { id_medico: ID_MEDICO, fecha: fecha, estado: estado },
            dataType: 'json',
            success: function(response) {
                var citas = response;
                if (response.success && response.data) {
                    citas = response.data;
                }
                
                let html = '';
                let stats = { total: 0, programadas: 0, completadas: 0, pacientes: new Set() };
                
                if (citas.length === 0) {
                    html = '<tr><td colspan="7" class="text-center text-muted">No hay citas para esta fecha</td></tr>';
                } else {
                    for (let i = 0; i < citas.length; i++) {
                        let cita = citas[i];
                        stats.total++;
                        if (cita.estado === 'programada') stats.programadas++;
                        if (cita.estado === 'completada') stats.completadas++;
                        if (cita.nombre_paciente) stats.pacientes.add(cita.nombre_paciente);
                        
                        let badgeClass = 'badge-' + cita.estado;
                        html += `
                            <tr>
                                <td><i class="fas fa-clock"></i> ${cita.hora_inicio || ''} - ${cita.hora_fin || ''}</td>
                                <td><i class="fas fa-user-injured text-primary"></i> ${escapeHtml(cita.nombre_paciente || 'N/A')}</td>
                                <td>${escapeHtml(cita.cedula_paciente || '-')}</td>
                                <td>${escapeHtml(cita.telefono_paciente || '-')}</td>
                                <td>${escapeHtml(cita.motivo || '-')}</td>
                                <td><span class="${badgeClass}">${cita.estado || ''}</span></td>
                                <td>
                                    <button class="btn btn-info btn-sm btn-ver-detalle" data-id="${cita.id_cita}">
                                        <i class="fas fa-eye"></i> Ver
                                    </button>
                                    ${cita.estado === 'programada' ? `
                                    <button class="btn btn-success btn-sm btn-completar" data-id="${cita.id_cita}">
                                        <i class="fas fa-check"></i>
                                    </button>` : ''}
                                </td>
                            </tr>
                        `;
                    }
                }
                
                $('#tabla_citas').html(html);
                $('#total_hoy').text(stats.total);
                $('#citas_programadas').text(stats.programadas);
                $('#citas_completadas').text(stats.completadas);
                $('#pacientes_hoy').text(stats.pacientes.size);
            },
            error: function(xhr, status, error) {
                $('#tabla_citas').html('<tr><td colspan="7" class="text-center text-danger">Error al cargar las citas</td></tr>');
            }
        });
    }

    $(document).on('click', '.btn-ver-detalle', function() {
        let id = $(this).data('id');
        window.location.href = APP_URL + '/citas/detalle/' + id;
    });

    $(document).on('click', '.btn-completar', function() {
        let id = $(this).data('id');
        if (confirm('¿Marcar esta cita como completada?')) {
            $.ajax({
                url: APP_URL + '/api/citas/completar',
                type: 'POST',
                data: { id_cita: id },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        cargarCitas();
                    } else {
                        alert('Error al completar cita: ' + (response.message || 'Error desconocido'));
                    }
                },
                error: function(xhr, status, error) {
                    alert('Error al completar cita: ' + error);
                }
            });
        }
    });

    function escapeHtml(str) {
        if (!str) return '';
        return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    }
});
</script>

<?php include_once dirname(__DIR__) . '/layouts/footer.php'; ?>
