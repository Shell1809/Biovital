<?php
// vista/medico/med_detalle_cita.php

if($_SESSION['us_tipo'] != 2 || $_SESSION['rol'] != 'medico'){
    header('Location: ' . APP_URL . '/login/medico');
    exit();
}

$nombre_usuario = $_SESSION['nombre_us'] ?? 'Usuario';
$id_medico = $_SESSION['usuario'];
$cita = $_SESSION['cita_detalle'] ?? null;
unset($_SESSION['cita_detalle']);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <script>
        var APP_URL = '<?php echo APP_URL; ?>';
        var ID_MEDICO = <?php echo json_encode($id_medico); ?>;
        var ID_CITA = <?php echo json_encode($cita->id_cita ?? 0); ?>;
    </script>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="<?php echo APP_URL; ?>/js/config.js"></script>
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/css/css/all.min.css">
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/css/adminlte.min.css">
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/css/dashboard.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <title>Médico | Detalle de Cita</title>
    
    <style>
        .badge-programada { background-color: #007bff; color: white; padding: 8px 15px; border-radius: 20px; }
        .badge-completada { background-color: #28a745; color: white; padding: 8px 15px; border-radius: 20px; }
        .badge-cancelada { background-color: #dc3545; color: white; padding: 8px 15px; border-radius: 20px; }
        .detalle-card { border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
    </style>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
    </ul>
    <ul class="navbar-nav ml-auto">
        <a href="<?php echo APP_URL; ?>/logout" class="btn btn-danger btn-sm">
            <i class="fas fa-sign-out-alt"></i> Cerrar sesión
        </a>
    </ul>
</nav>

<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="<?php echo APP_URL; ?>/panel/medico" class="brand-link">
        <img src="<?php echo APP_URL; ?>/img/logo_azul.png" alt="Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light">BioVital</span>
    </a>
    <div class="sidebar">
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img id="avatar4" src="<?php echo APP_URL; ?>/img/avatar.png" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info">
                <a href="#" class="d-block"><?php echo htmlspecialchars($nombre_usuario); ?></a>
            </div>
        </div>
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu">
                <li class="nav-header"><i class="fas fa-user-md"></i> Médico</li>
                <li class="nav-item">
                    <a href="<?php echo APP_URL; ?>/perfil" class="nav-link">
                        <i class="nav-icon fas fa-user-cog"></i>
                        <p>Datos personales</p>
                    </a>
                </li>
                <li class="nav-header"><i class="fas fa-calendar-alt"></i> Citas</li>
                <li class="nav-item">
                    <a href="<?php echo APP_URL; ?>/citas" class="nav-link">
                        <i class="nav-icon fas fa-calendar-alt"></i>
                        <p>Mis Citas</p>
                    </a>
                </li>
                <li class="nav-header"><i class="fas fa-users"></i> Pacientes</li>
                <li class="nav-item">
                    <a href="<?php echo APP_URL; ?>/medico/pacientes" class="nav-link">
                        <i class="nav-icon fas fa-users"></i>
                        <p>Mis Pacientes</p>
                    </a>
                </li>
                <li class="nav-header"><i class="fas fa-prescription"></i> Recetas</li>
                <li class="nav-item">
                    <a href="<?php echo APP_URL; ?>/recetas" class="nav-link">
                        <i class="nav-icon fas fa-prescription-bottle-alt"></i>
                        <p>Gestionar Recetas</p>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</aside>

<!-- Content Wrapper -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><i class="fas fa-calendar-alt"></i> Detalle de Cita</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo APP_URL; ?>/panel/medico">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo APP_URL; ?>/citas">Mis Citas</a></li>
                        <li class="breadcrumb-item active">Detalle</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            
            <?php if ($cita): ?>
                <!-- Welcome Banner -->
                <div class="bv-welcome-banner bv-animate">
                    <h2><i class="fas fa-calendar-check"></i> Detalle de Cita #<?php echo htmlspecialchars($cita->id_cita); ?></h2>
                    <p>Información detallada de la cita con el paciente.</p>
                    <div class="bv-role-tag"><i class="fas fa-user-md"></i> Médico</div>
                </div>

                <!-- Detalle Principal -->
                <div class="row">
                    <div class="col-md-8">
                        <div class="card detalle-card">
                            <div class="card-header">
                                <h3 class="card-title"><i class="fas fa-info-circle"></i> Información de la Cita</h3>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <p><strong><i class="fas fa-calendar-alt"></i> Fecha:</strong> <?php echo htmlspecialchars($cita->fecha_cita); ?></p>
                                        <p><strong><i class="fas fa-clock"></i> Hora:</strong> <?php echo htmlspecialchars($cita->hora_inicio); ?> - <?php echo htmlspecialchars($cita->hora_fin); ?></p>
                                        <p><strong><i class="fas fa-user-injured"></i> Paciente:</strong> <?php echo htmlspecialchars($cita->nombre_paciente ?? 'N/A'); ?></p>
                                        <p><strong><i class="fas fa-id-card"></i> Cédula:</strong> <?php echo htmlspecialchars($cita->cedula_paciente ?? 'N/A'); ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <p><strong><i class="fas fa-phone"></i> Teléfono:</strong> <?php echo htmlspecialchars($cita->telefono_paciente ?? 'N/A'); ?></p>
                                        <p><strong><i class="fas fa-building"></i> Consultorio:</strong> <?php echo htmlspecialchars($cita->consultorio_nombre ?? 'N/A'); ?></p>
                                        <p><strong><i class="fas fa-video"></i> Tipo:</strong> <?php echo htmlspecialchars($cita->tipo_cita ?? 'presencial'); ?></p>
                                        <p><strong><i class="fas fa-info-circle"></i> Estado:</strong> <span class="badge badge-<?php echo htmlspecialchars($cita->estado ?? 'programada'); ?>"><?php echo htmlspecialchars($cita->estado ?? 'programada'); ?></span></p>
                                    </div>
                                </div>
                                
                                <hr>
                                
                                <div class="row">
                                    <div class="col-md-12">
                                        <p><strong><i class="fas fa-comment-medical"></i> Motivo:</strong></p>
                                        <p><?php echo htmlspecialchars($cita->motivo ?? 'No especificado'); ?></p>
                                    </div>
                                </div>
                                
                                <?php if (!empty($cita->observaciones)): ?>
                                <div class="row">
                                    <div class="col-md-12">
                                        <p><strong><i class="fas fa-sticky-note"></i> Observaciones:</strong></p>
                                        <p><?php echo htmlspecialchars($cita->observaciones); ?></p>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="card detalle-card">
                            <div class="card-header">
                                <h3 class="card-title"><i class="fas fa-cog"></i> Acciones</h3>
                            </div>
                            <div class="card-body">
                                <?php if ($cita->estado == 'programada'): ?>
                                    <button class="btn btn-success btn-block mb-2" onclick="completarCita()">
                                        <i class="fas fa-check-circle"></i> Completar Cita
                                    </button>
                                    <button class="btn btn-info btn-block mb-2" onclick="window.print()">
                                        <i class="fas fa-print"></i> Imprimir
                                    </button>
                                    <a href="<?php echo APP_URL; ?>/recetas" class="btn btn-primary btn-block mb-2">
                                        <i class="fas fa-prescription"></i> Crear Receta
                                    </a>
                                <?php elseif ($cita->estado == 'completada'): ?>
                                    <button class="btn btn-success btn-block mb-2" disabled>
                                        <i class="fas fa-check-circle"></i> Cita Completada
                                    </button>
                                    <button class="btn btn-info btn-block mb-2" onclick="window.print()">
                                        <i class="fas fa-print"></i> Imprimir
                                    </button>
                                    <a href="<?php echo APP_URL; ?>/recetas" class="btn btn-primary btn-block mb-2">
                                        <i class="fas fa-prescription"></i> Crear Receta
                                    </a>
                                <?php elseif ($cita->estado == 'cancelada'): ?>
                                    <button class="btn btn-danger btn-block mb-2" disabled>
                                        <i class="fas fa-times-circle"></i> Cita Cancelada
                                    </button>
                                <?php endif; ?>
                                
                                <a href="<?php echo APP_URL; ?>/citas" class="btn btn-secondary btn-block">
                                    <i class="fas fa-arrow-left"></i> Volver a Mis Citas
                                </a>
                            </div>
                        </div>

                        <div class="card detalle-card mt-3">
                            <div class="card-header">
                                <h3 class="card-title"><i class="fas fa-history"></i> Historial</h3>
                            </div>
                            <div class="card-body">
                                <p><strong>Fecha de creación:</strong> <?php echo htmlspecialchars($cita->fecha_creacion ?? 'N/A'); ?></p>
                                <?php if (!empty($cita->fecha_completada)): ?>
                                <p><strong>Fecha completada:</strong> <?php echo htmlspecialchars($cita->fecha_completada); ?></p>
                                <?php endif; ?>
                                <?php if (!empty($cita->fecha_cancelacion)): ?>
                                <p><strong>Fecha cancelación:</strong> <?php echo htmlspecialchars($cita->fecha_cancelacion); ?></p>
                                <p><strong>Motivo cancelación:</strong> <?php echo htmlspecialchars($cita->motivo_cancelacion ?? 'N/A'); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i> No se encontró la cita solicitada.
                </div>
                <a href="<?php echo APP_URL; ?>/citas" class="btn btn-primary">Volver a Mis Citas</a>
            <?php endif; ?>
        </div>
    </section>
</div>

<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2024 BioVital.</strong> Todos los derechos reservados.
</footer>

</div>

<script src="<?php echo APP_URL; ?>/js/adminlte.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
function completarCita() {
    if (confirm('¿Estás seguro de que deseas marcar esta cita como completada?')) {
        $.ajax({
            url: APP_URL + '/api/citas/completar',
            type: 'POST',
            data: { id_cita: ID_CITA },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    alert('Cita completada exitosamente');
                    window.location.href = APP_URL + '/citas';
                } else {
                    alert('Error al completar cita: ' + (response.message || 'Error desconocido'));
                }
            },
            error: function(xhr, status, error) {
                alert('Error al completar cita: ' + error);
            }
        });
    }
}
</script>

<?php include_once dirname(__DIR__) . '/layouts/footer.php'; ?>
