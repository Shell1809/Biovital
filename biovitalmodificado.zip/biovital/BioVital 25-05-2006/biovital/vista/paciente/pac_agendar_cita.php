<?php
// vista/paciente/pac_agendar_cita.php

if($_SESSION['us_tipo'] != 1 || $_SESSION['rol'] != 'paciente'){
    header('Location: ' . APP_URL . '/login/paciente');
    exit();
}

$nombre_usuario = $_SESSION['nombre_us'] ?? 'Usuario';
$id_paciente = $_SESSION['usuario'];
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <script>
        var APP_URL = '<?php echo APP_URL; ?>';
        var ID_PACIENTE = <?php echo json_encode($id_paciente); ?>;
    </script>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="<?php echo APP_URL; ?>/js/config.js"></script>
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/css/css/all.min.css">
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/css/adminlte.min.css">
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/css/dashboard.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <title>Paciente | Agendar Cita</title>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
    </ul>
    <ul class="navbar-nav ml-auto">
        <a href="<?php echo APP_URL; ?>/logout" class="btn btn-danger btn-sm">
            <i class="fas fa-sign-out-alt"></i> Cerrar sesión
        </a>
    </ul>
</nav>

<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="<?php echo APP_URL; ?>/panel/paciente" class="brand-link">
        <img src="<?php echo APP_URL; ?>/img/logo_azul.png" alt="Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light">BioVital</span>
    </a>
    <div class="sidebar">
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img id="avatar4" src="<?php echo APP_URL; ?>/img/avatar.png" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info">
                <a href="#" class="d-block"><?php echo htmlspecialchars($nombre_usuario); ?></a>
            </div>
        </div>
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu">
                <li class="nav-header"><i class="fas fa-user-injured"></i> Usuario</li>
                <li class="nav-item">
                    <a href="<?php echo APP_URL; ?>/perfil" class="nav-link">
                        <i class="nav-icon fas fa-user-cog"></i>
                        <p>Datos personales</p>
                    </a>
                </li>
                <li class="nav-header"><i class="fas fa-calendar-alt"></i> Citas</li>
                <li class="nav-item">
                    <a href="<?php echo APP_URL; ?>/citas" class="nav-link">
                        <i class="nav-icon fas fa-calendar-alt"></i>
                        <p>Mis Citas</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo APP_URL; ?>/citas/agendar" class="nav-link active">
                        <i class="nav-icon fas fa-calendar-plus"></i>
                        <p>Agendar Cita</p>
                    </a>
                </li>
                <li class="nav-header"><i class="fas fa-clinic-medical"></i> Clínica</li>
                <li class="nav-item">
                    <a href="<?php echo APP_URL; ?>/paciente/recetas" class="nav-link">
                        <i class="nav-icon fas fa-prescription-bottle-alt"></i>
                        <p>Mis Recetas</p>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</aside>

<!-- Content Wrapper -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><i class="fas fa-calendar-plus"></i> Agendar Nueva Cita</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo APP_URL; ?>/panel/paciente">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo APP_URL; ?>/citas">Mis Citas</a></li>
                        <li class="breadcrumb-item active">Agendar</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            
            <!-- Welcome Banner -->
            <div class="bv-welcome-banner bv-animate">
                <h2><i class="fas fa-calendar-plus"></i> Agendar Cita</h2>
                <p>Completa el formulario para agendar una nueva cita médica.</p>
                <div class="bv-role-tag"><i class="fas fa-user-injured"></i> Paciente</div>
            </div>

            <!-- Formulario de Agendar Cita -->
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fas fa-edit"></i> Datos de la Cita</h3>
                        </div>
                        <div class="card-body">
                            <form id="formAgendarCita">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label><i class="fas fa-stethoscope"></i> Especialidad *</label>
                                            <select class="form-control" id="id_especialidad" required>
                                                <option value="">Seleccione especialidad</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label><i class="fas fa-user-md"></i> Médico *</label>
                                            <select class="form-control" id="id_medico" required disabled>
                                                <option value="">Seleccione médico</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label><i class="fas fa-calendar-alt"></i> Fecha de la Cita *</label>
                                            <input type="date" class="form-control" id="fecha_cita" required min="<?php echo date('Y-m-d'); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label><i class="fas fa-clock"></i> Hora Inicio *</label>
                                            <input type="time" class="form-control" id="hora_inicio" required>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label><i class="fas fa-clock"></i> Hora Fin *</label>
                                            <input type="time" class="form-control" id="hora_fin" required>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label><i class="fas fa-comment-medical"></i> Motivo de la Consulta *</label>
                                    <textarea class="form-control" id="motivo" rows="3" required placeholder="Describa el motivo de su consulta..."></textarea>
                                </div>

                                <div class="form-group">
                                    <label><i class="fas fa-video"></i> Tipo de Cita</label>
                                    <select class="form-control" id="tipo_cita">
                                        <option value="presencial">Presencial</option>
                                        <option value="virtual">Virtual</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label><i class="fas fa-sticky-note"></i> Observaciones Adicionales</label>
                                    <textarea class="form-control" id="observaciones" rows="2" placeholder="Cualquier información adicional..."></textarea>
                                </div>

                                <div class="alert alert-info" id="disponibilidad_info" style="display: none;">
                                    <i class="fas fa-info-circle"></i> <span id="disponibilidad_text"></span>
                                </div>

                                <button type="submit" class="btn btn-primary btn-block">
                                    <i class="fas fa-calendar-check"></i> Agendar Cita
                                </button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fas fa-info-circle"></i> Información</h3>
                        </div>
                        <div class="card-body">
                            <div class="text-centered-box">
                                <h4><i class="fas fa-lightbulb"></i> Consejos</h4>
                                <ul>
                                    <li>Seleccione primero la especialidad</li>
                                    <li>Luego elija un médico disponible</li>
                                    <li>Verifique la fecha y hora</li>
                                    <li>El sistema verificará disponibilidad</li>
                                </ul>
                            </div>

                            <div class="text-centered-box mt-3">
                                <h4><i class="fas fa-phone"></i> Contacto</h4>
                                <p>Si tiene dudas, contáctenos:</p>
                                <p><i class="fas fa-phone"></i> +58 XXX-XXXXXXX</p>
                                <p><i class="fas fa-envelope"></i> contacto@biovital.com</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2024 BioVital.</strong> Todos los derechos reservados.
</footer>

</div>

<script src="<?php echo APP_URL; ?>/js/adminlte.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
$(document).ready(function() {
    cargarEspecialidades();

    $('#id_especialidad').change(function() {
        let id_especialidad = $(this).val();
        if (id_especialidad) {
            cargarMedicosPorEspecialidad(id_especialidad);
        } else {
            $('#id_medico').html('<option value="">Seleccione médico</option>').prop('disabled', true);
        }
    });

    $('#fecha_cita, #hora_inicio, #hora_fin').change(function() {
        verificarDisponibilidad();
    });

    $('#formAgendarCita').submit(function(e) {
        e.preventDefault();
        agendarCita();
    });

    function cargarEspecialidades() {
        $.ajax({
            url: APP_URL + '/api/ubicacion/especialidades',
            type: 'POST',
            dataType: 'json',
            success: function(response) {
                let especialidades = response;
                if (response.success && response.data) {
                    especialidades = response.data;
                }
                
                let html = '<option value="">Seleccione especialidad</option>';
                for (let i = 0; i < especialidades.length; i++) {
                    html += '<option value="' + especialidades[i].id_especialidad + '">' + escapeHtml(especialidades[i].nombre) + '</option>';
                }
                $('#id_especialidad').html(html);
            },
            error: function(xhr, status, error) {
                console.error('Error al cargar especialidades:', error);
            }
        });
    }

    function cargarMedicosPorEspecialidad(id_especialidad) {
        $('#id_medico').html('<option value="">Cargando médicos...</option>').prop('disabled', true);
        
        $.ajax({
            url: APP_URL + '/api/especialidades/listar-medicos',
            type: 'POST',
            data: { id_especialidad: id_especialidad },
            dataType: 'json',
            success: function(response) {
                let medicos = response;
                if (response.success && response.data) {
                    medicos = response.data;
                }
                
                let html = '<option value="">Seleccione médico</option>';
                for (let i = 0; i < medicos.length; i++) {
                    html += '<option value="' + medicos[i].id_medico + '">' + escapeHtml(medicos[i].nombre_medico + ' ' + medicos[i].apellido_medico) + '</option>';
                }
                $('#id_medico').html(html).prop('disabled', false);
            },
            error: function(xhr, status, error) {
                $('#id_medico').html('<option value="">Error al cargar médicos</option>');
                console.error('Error al cargar médicos:', error);
            }
        });
    }

    function verificarDisponibilidad() {
        let id_medico = $('#id_medico').val();
        let fecha = $('#fecha_cita').val();
        let hora_inicio = $('#hora_inicio').val();
        let hora_fin = $('#hora_fin').val();

        if (id_medico && fecha && hora_inicio && hora_fin) {
            $.ajax({
                url: APP_URL + '/api/citas/verificar-disponibilidad',
                type: 'POST',
                data: { id_medico: id_medico, fecha: fecha, hora_inicio: hora_inicio, hora_fin: hora_fin },
                dataType: 'json',
                success: function(response) {
                    let disponible = response.disponible;
                    if (response.success && response.data) {
                        disponible = response.data.disponible;
                    }
                    
                    $('#disponibilidad_info').show();
                    if (disponible) {
                        $('#disponibilidad_info').removeClass('alert-danger').addClass('alert-success');
                        $('#disponibilidad_text').html('<i class="fas fa-check-circle"></i> Horario disponible para agendar cita');
                    } else {
                        $('#disponibilidad_info').removeClass('alert-success').addClass('alert-danger');
                        $('#disponibilidad_text').html('<i class="fas fa-times-circle"></i> Horario no disponible. Seleccione otro horario.');
                    }
                },
                error: function(xhr, status, error) {
                    $('#disponibilidad_info').hide();
                }
            });
        }
    }

    function agendarCita() {
        let datos = {
            id_paciente: ID_PACIENTE,
            id_medico: $('#id_medico').val(),
            id_especialidad: $('#id_especialidad').val(),
            fecha_cita: $('#fecha_cita').val(),
            hora_inicio: $('#hora_inicio').val(),
            hora_fin: $('#hora_fin').val(),
            motivo: $('#motivo').val(),
            tipo_cita: $('#tipo_cita').val(),
            observaciones: $('#observaciones').val()
        };

        $.ajax({
            url: APP_URL + '/api/citas/crear',
            type: 'POST',
            data: datos,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    alert('¡Cita agendada exitosamente!');
                    window.location.href = APP_URL + '/citas';
                } else {
                    alert('Error al agendar cita: ' + (response.message || 'Error desconocido'));
                }
            },
            error: function(xhr, status, error) {
                alert('Error al agendar cita: ' + error);
            }
        });
    }

    function escapeHtml(str) {
        if (!str) return '';
        return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    }
});
</script>

<?php include_once dirname(__DIR__) . '/layouts/footer.php'; ?>
