<?php
// vista/paciente/pac_citas.php

if($_SESSION['us_tipo'] != 1 || $_SESSION['rol'] != 'paciente'){
    header('Location: ' . APP_URL . '/login/paciente');
    exit();
}

$nombre_usuario = $_SESSION['nombre_us'] ?? 'Usuario';
$id_paciente = $_SESSION['usuario'];
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <script>
        var APP_URL = '<?php echo APP_URL; ?>';
        var ID_PACIENTE = <?php echo json_encode($id_paciente); ?>;
    </script>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="<?php echo APP_URL; ?>/js/config.js"></script>
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/css/css/all.min.css">
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/css/adminlte.min.css">
    <link rel="stylesheet" href="<?php echo APP_URL; ?>/css/dashboard.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <title>Paciente | Mis Citas</title>
    
    <style>
        .badge-programada { background-color: #007bff; color: white; padding: 5px 10px; border-radius: 20px; font-size: 11px; }
        .badge-completada { background-color: #28a745; color: white; padding: 5px 10px; border-radius: 20px; font-size: 11px; }
        .badge-cancelada { background-color: #dc3545; color: white; padding: 5px 10px; border-radius: 20px; font-size: 11px; }
        .badge-no_asistio { background-color: #ffc107; color: #333; padding: 5px 10px; border-radius: 20px; font-size: 11px; }
        .cita-card { transition: transform 0.2s; margin-bottom: 20px; }
        .cita-card:hover { transform: translateY(-3px); box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
    </style>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
    </ul>
    <ul class="navbar-nav ml-auto">
        <a href="<?php echo APP_URL; ?>/logout" class="btn btn-danger btn-sm">
            <i class="fas fa-sign-out-alt"></i> Cerrar sesión
        </a>
    </ul>
</nav>

<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="<?php echo APP_URL; ?>/panel/paciente" class="brand-link">
        <img src="<?php echo APP_URL; ?>/img/logo_azul.png" alt="Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light">BioVital</span>
    </a>
    <div class="sidebar">
        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img id="avatar4" src="<?php echo APP_URL; ?>/img/avatar.png" class="img-circle elevation-2" alt="User Image">
            </div>
            <div class="info">
                <a href="#" class="d-block"><?php echo htmlspecialchars($nombre_usuario); ?></a>
            </div>
        </div>
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu">
                <li class="nav-header"><i class="fas fa-user-injured"></i> Usuario</li>
                <li class="nav-item">
                    <a href="<?php echo APP_URL; ?>/perfil" class="nav-link">
                        <i class="nav-icon fas fa-user-cog"></i>
                        <p>Datos personales</p>
                    </a>
                </li>
                <li class="nav-header"><i class="fas fa-calendar-alt"></i> Citas</li>
                <li class="nav-item">
                    <a href="<?php echo APP_URL; ?>/citas" class="nav-link active">
                        <i class="nav-icon fas fa-calendar-alt"></i>
                        <p>Mis Citas</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo APP_URL; ?>/citas/agendar" class="nav-link">
                        <i class="nav-icon fas fa-calendar-plus"></i>
                        <p>Agendar Cita</p>
                    </a>
                </li>
                <li class="nav-header"><i class="fas fa-clinic-medical"></i> Clínica</li>
                <li class="nav-item">
                    <a href="<?php echo APP_URL; ?>/paciente/recetas" class="nav-link">
                        <i class="nav-icon fas fa-prescription-bottle-alt"></i>
                        <p>Mis Recetas</p>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</aside>

<!-- Content Wrapper -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><i class="fas fa-calendar-alt"></i> Mis Citas Médicas</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo APP_URL; ?>/panel/paciente">Home</a></li>
                        <li class="breadcrumb-item active">Mis Citas</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            
            <!-- Welcome Banner -->
            <div class="bv-welcome-banner bv-animate">
                <h2><i class="fas fa-calendar-check"></i> Mis Citas</h2>
                <p>Consulta y gestiona tus citas médicas programadas.</p>
                <div class="bv-role-tag"><i class="fas fa-user-injured"></i> Historial de Citas</div>
            </div>

            <!-- Stats Cards -->
            <div class="row">
                <div class="col-md-3 col-sm-6 col-12">
                    <div class="info-box bv-animate bv-animate-delay-1">
                        <span class="info-box-icon bg-info"><i class="fas fa-calendar-alt"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Total Citas</span>
                            <span class="info-box-number" id="total_citas">0</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-12">
                    <div class="info-box bv-animate bv-animate-delay-2">
                        <span class="info-box-icon bg-success"><i class="fas fa-clock"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Programadas</span>
                            <span class="info-box-number" id="citas_programadas">0</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-12">
                    <div class="info-box bv-animate bv-animate-delay-3">
                        <span class="info-box-icon bg-primary"><i class="fas fa-check-circle"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Completadas</span>
                            <span class="info-box-number" id="citas_completadas">0</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-12">
                    <div class="info-box bv-animate bv-animate-delay-4">
                        <span class="info-box-icon bg-danger"><i class="fas fa-times-circle"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Canceladas</span>
                            <span class="info-box-number" id="citas_canceladas">0</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Próximas Citas -->
            <div class="row mt-3">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fas fa-clock"></i> Próximas Citas</h3>
                            <div class="card-tools">
                                <button class="btn btn-default btn-sm" id="btnRefresh">
                                    <i class="fas fa-sync-alt"></i> Actualizar
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div id="proximas_citas_container">
                                <div class="text-center">
                                    <div class="spinner-border text-primary" role="status">
                                        <span class="sr-only">Cargando...</span>
                                    </div>
                                    <p>Cargando próximas citas...</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tabla de Citas -->
            <div class="row mt-3">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title"><i class="fas fa-list"></i> Historial de Citas</h3>
                        </div>
                        <div class="card-body table-responsive p-0">
                            <table class="table table-hover text-nowrap">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Fecha</th>
                                        <th>Hora</th>
                                        <th>Médico</th>
                                        <th>Especialidad</th>
                                        <th>Estado</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody id="tabla_citas">
                                    <tr><td colspan="7" class="text-center">
                                        <div class="spinner-border text-primary" role="status">
                                            <span class="sr-only">Cargando...</span>
                                        </div>
                                        <p>Cargando citas...</p>
                                    </td></tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2024 BioVital.</strong> Todos los derechos reservados.
</footer>

</div>

<script src="<?php echo APP_URL; ?>/js/adminlte.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
$(document).ready(function() {
    cargarCitas();
    cargarProximasCitas();

    $('#btnRefresh').click(function() {
        cargarCitas();
        cargarProximasCitas();
    });

    function cargarCitas() {
        $('#tabla_citas').html('<tr><td colspan="7" class="text-center"><div class="spinner-border text-primary"></div><p>Cargando citas...</p></td></tr>');
        
        $.ajax({
            url: APP_URL + '/api/citas/mis-citas',
            type: 'POST',
            data: { id_paciente: ID_PACIENTE },
            dataType: 'json',
            success: function(response) {
                var citas = response;
                if (response.success && response.data) {
                    citas = response.data;
                }
                
                let html = '';
                let stats = { total: 0, programadas: 0, completadas: 0, canceladas: 0 };
                
                if (citas.length === 0) {
                    html = '<tr><td colspan="7" class="text-center text-muted">No hay citas registradas</td></tr>';
                } else {
                    for (let i = 0; i < citas.length; i++) {
                        let cita = citas[i];
                        stats.total++;
                        if (cita.estado === 'programada') stats.programadas++;
                        if (cita.estado === 'completada') stats.completadas++;
                        if (cita.estado === 'cancelada') stats.canceladas++;
                        
                        let badgeClass = 'badge-' + cita.estado;
                        html += `
                            <tr>
                                <td><span class="badge badge-secondary">${cita.id_cita || ''}</span></td>
                                <td><i class="fas fa-calendar-alt"></i> ${cita.fecha_cita || ''}</td>
                                <td><i class="fas fa-clock"></i> ${cita.hora_inicio || ''} - ${cita.hora_fin || ''}</td>
                                <td><i class="fas fa-user-md text-success"></i> ${escapeHtml(cita.nombre_medico || 'N/A')}</td>
                                <td>${escapeHtml(cita.especialidad_nombre || 'N/A')}</td>
                                <td><span class="${badgeClass}">${cita.estado || ''}</span></td>
                                <td>
                                    <button class="btn btn-info btn-sm btn-ver-detalle" data-id="${cita.id_cita}">
                                        <i class="fas fa-eye"></i> Ver
                                    </button>
                                </td>
                            </tr>
                        `;
                    }
                }
                
                $('#tabla_citas').html(html);
                $('#total_citas').text(stats.total);
                $('#citas_programadas').text(stats.programadas);
                $('#citas_completadas').text(stats.completadas);
                $('#citas_canceladas').text(stats.canceladas);
            },
            error: function(xhr, status, error) {
                $('#tabla_citas').html('<tr><td colspan="7" class="text-center text-danger">Error al cargar las citas</td></tr>');
            }
        });
    }

    function cargarProximasCitas() {
        $('#proximas_citas_container').html('<div class="text-center"><div class="spinner-border text-primary"></div><p>Cargando...</p></div>');
        
        $.ajax({
            url: APP_URL + '/api/citas/proximas',
            type: 'POST',
            data: { id_paciente: ID_PACIENTE, limit: 3 },
            dataType: 'json',
            success: function(response) {
                var citas = response;
                if (response.success && response.data) {
                    citas = response.data;
                }
                
                let html = '';
                if (citas.length === 0) {
                    html = '<div class="text-center text-muted"><p>No tienes próximas citas programadas</p><a href="' + APP_URL + '/citas/agendar" class="btn btn-primary">Agendar Cita</a></div>';
                } else {
                    html = '<div class="row">';
                    for (let i = 0; i < citas.length; i++) {
                        let cita = citas[i];
                        html += `
                            <div class="col-md-4">
                                <div class="card cita-card">
                                    <div class="card-body">
                                        <h5 class="card-title"><i class="fas fa-calendar-alt"></i> ${cita.fecha_cita}</h5>
                                        <p class="card-text"><i class="fas fa-clock"></i> ${cita.hora_inicio}</p>
                                        <p class="card-text"><i class="fas fa-user-md"></i> ${escapeHtml(cita.nombre_medico || 'N/A')}</p>
                                        <p class="card-text"><small>${escapeHtml(cita.especialidad_nombre || '')}</small></p>
                                        <button class="btn btn-sm btn-info btn-ver-detalle" data-id="${cita.id_cita}">Ver Detalle</button>
                                    </div>
                                </div>
                            </div>
                        `;
                    }
                    html += '</div>';
                }
                
                $('#proximas_citas_container').html(html);
            },
            error: function(xhr, status, error) {
                $('#proximas_citas_container').html('<div class="text-center text-danger">Error al cargar próximas citas</div>');
            }
        });
    }

    $(document).on('click', '.btn-ver-detalle', function() {
        let id = $(this).data('id');
        window.location.href = APP_URL + '/citas/detalle/' + id;
    });

    function escapeHtml(str) {
        if (!str) return '';
        return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    }
});
</script>

<?php include_once dirname(__DIR__) . '/layouts/footer.php'; ?>
