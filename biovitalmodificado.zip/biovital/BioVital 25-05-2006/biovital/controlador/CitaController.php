<?php
// controlador/CitaController.php

class CitaController {
    
    private $cita;
    
    public function __construct() {
        // Verificar autenticación
        if (!isset($_SESSION['usuario']) || !isset($_SESSION['rol'])) {
            if ($this->isAjax()) {
                jsonResponse(['error' => 'No autorizado'], 401);
            } else {
                redirect('login');
            }
            exit();
        }
        
        // Cargar el modelo
        require_once MODEL_PATH . '/Cita.php';
        $this->cita = new Cita();
    }
    
    private function isAjax() {
        return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
    }
    
    // ==================== VISTAS ====================
    
    /**
     * Vista principal de citas (según el rol del usuario)
     */
    public function index() {
        $rol = $_SESSION['rol'];
        
        switch($rol) {
            case 'paciente':
                $vista = 'paciente/pac_citas';
                break;
            case 'medico':
                $vista = 'medico/med_citas';
                break;
            case 'asistente':
                $vista = 'asistente/asi_citas';
                break;
            case 'administrador':
                $vista = 'administrador/adm_citas';
                break;
            default:
                redirect('login');
                return;
        }
        
        renderView($vista);
    }
    
    /**
     * Vista para agendar nueva cita (paciente)
     */
    public function agendar() {
        if ($_SESSION['rol'] !== 'paciente') {
            redirect('login/paciente');
            return;
        }
        renderView('paciente/pac_agendar_cita');
    }
    
    /**
     * Vista para ver detalle de cita
     */
    public function detalle() {
        $id_cita = $_GET['id'] ?? 0;
        
        if (!$id_cita) {
            redirect('panel/' . $_SESSION['rol']);
            return;
        }
        
        $cita = $this->cita->obtenerPorId($id_cita);
        
        if (!$cita) {
            redirect('panel/' . $_SESSION['rol']);
            return;
        }
        
        // Verificar permisos según rol
        $rol = $_SESSION['rol'];
        $id_usuario = $_SESSION['usuario'];
        
        if ($rol === 'paciente' && $cita->id_paciente != $id_usuario) {
            redirect('panel/paciente');
            return;
        }
        
        if ($rol === 'medico' && $cita->id_medico != $id_usuario) {
            redirect('panel/medico');
            return;
        }
        
        // Pasar datos a la vista
        $_SESSION['cita_detalle'] = $cita;
        
        switch($rol) {
            case 'paciente':
                renderView('paciente/pac_detalle_cita');
                break;
            case 'medico':
                renderView('medico/med_detalle_cita');
                break;
            case 'asistente':
                renderView('asistente/asi_detalle_cita');
                break;
            case 'administrador':
                renderView('administrador/adm_detalle_cita');
                break;
        }
    }
    
    // ==================== API - LISTAR CITAS ====================
    
    /**
     * Listar citas del paciente actual
     */
    public function listarMisCitas() {
        $id_paciente = $_POST['id_paciente'] ?? $_SESSION['usuario'];
        $estado = $_POST['estado'] ?? null;
        
        if ($_SESSION['rol'] === 'paciente' && $id_paciente != $_SESSION['usuario']) {
            jsonResponse(['error' => 'No autorizado'], 403);
            return;
        }
        
        try {
            $citas = $this->cita->listarPorPaciente($id_paciente, $estado);
            
            $resultado = array();
            foreach ($citas as $c) {
                $resultado[] = array(
                    'id_cita' => $c->id_cita,
                    'fecha_cita' => $c->fecha_cita,
                    'hora_inicio' => $c->hora_inicio,
                    'hora_fin' => $c->hora_fin,
                    'estado' => $c->estado,
                    'tipo_cita' => $c->tipo_cita,
                    'motivo' => $c->motivo,
                    'nombre_medico' => $c->nombre_medico ?? 'N/A',
                    'especialidad_nombre' => $c->especialidad_nombre ?? 'N/A',
                    'consultorio_nombre' => $c->consultorio_nombre ?? 'N/A'
                );
            }
            
            jsonResponse($resultado);
        } catch(Exception $e) {
            error_log("Error en listarMisCitas: " . $e->getMessage());
            jsonResponse(['error' => 'Error al cargar citas'], 500);
        }
    }
    
    /**
     * Listar citas del médico actual
     */
    public function listarCitasMedico() {
        $id_medico = $_POST['id_medico'] ?? $_SESSION['usuario'];
        $fecha = $_POST['fecha'] ?? null;
        $estado = $_POST['estado'] ?? null;
        
        if ($_SESSION['rol'] === 'medico' && $id_medico != $_SESSION['usuario']) {
            jsonResponse(['error' => 'No autorizado'], 403);
            return;
        }
        
        try {
            $citas = $this->cita->listarPorMedico($id_medico, $fecha, $estado);
            
            $resultado = array();
            foreach ($citas as $c) {
                $resultado[] = array(
                    'id_cita' => $c->id_cita,
                    'fecha_cita' => $c->fecha_cita,
                    'hora_inicio' => $c->hora_inicio,
                    'hora_fin' => $c->hora_fin,
                    'estado' => $c->estado,
                    'tipo_cita' => $c->tipo_cita,
                    'motivo' => $c->motivo,
                    'nombre_paciente' => $c->nombre_paciente ?? 'N/A',
                    'cedula_paciente' => $c->cedula_paciente ?? '',
                    'telefono_paciente' => $c->telefono_paciente ?? '',
                    'especialidad_nombre' => $c->especialidad_nombre ?? 'N/A',
                    'consultorio_nombre' => $c->consultorio_nombre ?? 'N/A'
                );
            }
            
            jsonResponse($resultado);
        } catch(Exception $e) {
            error_log("Error en listarCitasMedico: " . $e->getMessage());
            jsonResponse(['error' => 'Error al cargar citas'], 500);
        }
    }
    
    /**
     * Listar citas por fecha (para secretaria)
     */
    public function listarPorFecha() {
        $fecha = $_POST['fecha'] ?? date('Y-m-d');
        $id_especialidad = $_POST['id_especialidad'] ?? null;
        
        if ($_SESSION['rol'] !== 'asistente' && $_SESSION['rol'] !== 'administrador') {
            jsonResponse(['error' => 'No autorizado'], 403);
            return;
        }
        
        try {
            $citas = $this->cita->listarPorFecha($fecha, $id_especialidad);
            
            $resultado = array();
            foreach ($citas as $c) {
                $resultado[] = array(
                    'id_cita' => $c->id_cita,
                    'fecha_cita' => $c->fecha_cita,
                    'hora_inicio' => $c->hora_inicio,
                    'hora_fin' => $c->hora_fin,
                    'estado' => $c->estado,
                    'tipo_cita' => $c->tipo_cita,
                    'motivo' => $c->motivo,
                    'nombre_paciente' => $c->nombre_paciente ?? 'N/A',
                    'nombre_medico' => $c->nombre_medico ?? 'N/A',
                    'especialidad_nombre' => $c->especialidad_nombre ?? 'N/A'
                );
            }
            
            jsonResponse($resultado);
        } catch(Exception $e) {
            error_log("Error en listarPorFecha: " . $e->getMessage());
            jsonResponse(['error' => 'Error al cargar citas'], 500);
        }
    }
    
    /**
     * Obtener próximas citas del paciente
     */
    public function proximasCitas() {
        $id_paciente = $_POST['id_paciente'] ?? $_SESSION['usuario'];
        $limit = $_POST['limit'] ?? 5;
        
        if ($_SESSION['rol'] === 'paciente' && $id_paciente != $_SESSION['usuario']) {
            jsonResponse(['error' => 'No autorizado'], 403);
            return;
        }
        
        try {
            $citas = $this->cita->listarProximas($id_paciente, $limit);
            
            $resultado = array();
            foreach ($citas as $c) {
                $resultado[] = array(
                    'id_cita' => $c->id_cita,
                    'fecha_cita' => $c->fecha_cita,
                    'hora_inicio' => $c->hora_inicio,
                    'hora_fin' => $c->hora_fin,
                    'nombre_medico' => $c->nombre_medico ?? 'N/A',
                    'especialidad_nombre' => $c->especialidad_nombre ?? 'N/A'
                );
            }
            
            jsonResponse($resultado);
        } catch(Exception $e) {
            error_log("Error en proximasCitas: " . $e->getMessage());
            jsonResponse(['error' => 'Error al cargar citas'], 500);
        }
    }
    
    // ==================== API - CRUD ====================
    
    /**
     * Crear nueva cita
     */
    public function crear() {
        if ($_SESSION['rol'] !== 'paciente' && $_SESSION['rol'] !== 'asistente') {
            jsonResponse(['success' => false, 'message' => 'No autorizado']);
            return;
        }
        
        $datos = array(
            'id_paciente' => $_POST['id_paciente'] ?? $_SESSION['usuario'],
            'id_medico' => $_POST['id_medico'] ?? 0,
            'id_consultorio' => $_POST['id_consultorio'] ?? 0,
            'id_especialidad' => $_POST['id_especialidad'] ?? 0,
            'fecha_cita' => $_POST['fecha_cita'] ?? '',
            'hora_inicio' => $_POST['hora_inicio'] ?? '',
            'hora_fin' => $_POST['hora_fin'] ?? '',
            'motivo' => $_POST['motivo'] ?? '',
            'estado' => 'programada',
            'tipo_cita' => $_POST['tipo_cita'] ?? 'presencial',
            'observaciones' => $_POST['observaciones'] ?? ''
        );
        
        // Validaciones
        if (empty($datos['id_paciente']) || empty($datos['id_medico']) || 
            empty($datos['fecha_cita']) || empty($datos['hora_inicio'])) {
            jsonResponse(['success' => false, 'message' => 'Todos los campos requeridos deben estar llenos']);
            return;
        }
        
        try {
            $resultado = $this->cita->crear($datos);
            jsonResponse($resultado);
        } catch(Exception $e) {
            error_log("Error en crear cita: " . $e->getMessage());
            jsonResponse(['success' => false, 'message' => 'Error del servidor'], 500);
        }
    }
    
    /**
     * Editar cita existente
     */
    public function editar() {
        $id_cita = $_POST['id_cita'] ?? 0;
        
        if (!$id_cita) {
            jsonResponse(['success' => false, 'message' => 'ID de cita no válido']);
            return;
        }
        
        // Verificar permisos
        $cita = $this->cita->obtenerPorId($id_cita);
        if (!$cita) {
            jsonResponse(['success' => false, 'message' => 'Cita no encontrada']);
            return;
        }
        
        $rol = $_SESSION['rol'];
        $id_usuario = $_SESSION['usuario'];
        
        if ($rol === 'paciente' && $cita->id_paciente != $id_usuario) {
            jsonResponse(['success' => false, 'message' => 'No autorizado']);
            return;
        }
        
        if ($rol === 'medico' && $cita->id_medico != $id_usuario) {
            jsonResponse(['success' => false, 'message' => 'No autorizado']);
            return;
        }
        
        $datos = array(
            'fecha_cita' => $_POST['fecha_cita'] ?? '',
            'hora_inicio' => $_POST['hora_inicio'] ?? '',
            'hora_fin' => $_POST['hora_fin'] ?? '',
            'motivo' => $_POST['motivo'] ?? '',
            'estado' => $_POST['estado'] ?? 'programada',
            'tipo_cita' => $_POST['tipo_cita'] ?? 'presencial',
            'observaciones' => $_POST['observaciones'] ?? ''
        );
        
        try {
            $resultado = $this->cita->editar($id_cita, $datos);
            jsonResponse($resultado);
        } catch(Exception $e) {
            error_log("Error en editar cita: " . $e->getMessage());
            jsonResponse(['success' => false, 'message' => 'Error del servidor'], 500);
        }
    }
    
    /**
     * Cancelar cita
     */
    public function cancelar() {
        $id_cita = $_POST['id_cita'] ?? 0;
        $motivo_cancelacion = $_POST['motivo_cancelacion'] ?? '';
        
        if (!$id_cita) {
            jsonResponse(['success' => false, 'message' => 'ID de cita no válido']);
            return;
        }
        
        // Verificar permisos
        $cita = $this->cita->obtenerPorId($id_cita);
        if (!$cita) {
            jsonResponse(['success' => false, 'message' => 'Cita no encontrada']);
            return;
        }
        
        $rol = $_SESSION['rol'];
        $id_usuario = $_SESSION['usuario'];
        
        if ($rol === 'paciente' && $cita->id_paciente != $id_usuario) {
            jsonResponse(['success' => false, 'message' => 'No autorizado']);
            return;
        }
        
        try {
            $resultado = $this->cita->cancelar($id_cita, $motivo_cancelacion);
            jsonResponse($resultado);
        } catch(Exception $e) {
            error_log("Error en cancelar cita: " . $e->getMessage());
            jsonResponse(['success' => false, 'message' => 'Error del servidor'], 500);
        }
    }
    
    /**
     * Completar cita (médico)
     */
    public function completar() {
        $id_cita = $_POST['id_cita'] ?? 0;
        
        if (!$id_cita) {
            jsonResponse(['success' => false, 'message' => 'ID de cita no válido']);
            return;
        }
        
        if ($_SESSION['rol'] !== 'medico' && $_SESSION['rol'] !== 'asistente') {
            jsonResponse(['success' => false, 'message' => 'No autorizado']);
            return;
        }
        
        try {
            $resultado = $this->cita->completar($id_cita);
            jsonResponse($resultado);
        } catch(Exception $e) {
            error_log("Error en completar cita: " . $e->getMessage());
            jsonResponse(['success' => false, 'message' => 'Error del servidor'], 500);
        }
    }
    
    // ==================== API - DISPONIBILIDAD ====================
    
    /**
     * Verificar disponibilidad de horario
     */
    public function verificarDisponibilidad() {
        $id_medico = $_POST['id_medico'] ?? 0;
        $fecha = $_POST['fecha'] ?? '';
        $hora_inicio = $_POST['hora_inicio'] ?? '';
        $hora_fin = $_POST['hora_fin'] ?? '';
        
        if (empty($id_medico) || empty($fecha) || empty($hora_inicio)) {
            jsonResponse(['success' => false, 'message' => 'Datos incompletos']);
            return;
        }
        
        try {
            $disponible = $this->cita->verificarDisponibilidad($id_medico, $fecha, $hora_inicio, $hora_fin);
            jsonResponse(['success' => true, 'disponible' => $disponible]);
        } catch(Exception $e) {
            error_log("Error en verificarDisponibilidad: " . $e->getMessage());
            jsonResponse(['success' => false, 'message' => 'Error del servidor'], 500);
        }
    }
    
    /**
     * Obtener horarios disponibles de un médico
     */
    public function horariosDisponibles() {
        $id_medico = $_POST['id_medico'] ?? 0;
        $fecha = $_POST['fecha'] ?? '';
        
        if (empty($id_medico) || empty($fecha)) {
            jsonResponse(['success' => false, 'message' => 'Datos incompletos']);
            return;
        }
        
        try {
            $horarios = $this->cita->obtenerHorariosDisponibles($id_medico, $fecha);
            jsonResponse(['success' => true, 'horarios' => $horarios]);
        } catch(Exception $e) {
            error_log("Error en horariosDisponibles: " . $e->getMessage());
            jsonResponse(['success' => false, 'message' => 'Error del servidor'], 500);
        }
    }
    
    // ==================== API - ESTADÍSTICAS ====================
    
    /**
     * Obtener estadísticas de citas
     */
    public function estadisticas() {
        $id_medico = $_POST['id_medico'] ?? null;
        $fecha_inicio = $_POST['fecha_inicio'] ?? null;
        $fecha_fin = $_POST['fecha_fin'] ?? null;
        
        if ($_SESSION['rol'] === 'medico' && $id_medico != $_SESSION['usuario']) {
            jsonResponse(['error' => 'No autorizado'], 403);
            return;
        }
        
        try {
            $stats = $this->cita->obtenerEstadisticas($id_medico, $fecha_inicio, $fecha_fin);
            jsonResponse($stats);
        } catch(Exception $e) {
            error_log("Error en estadisticas: " . $e->getMessage());
            jsonResponse(['error' => 'Error al cargar estadísticas'], 500);
        }
    }
}
?>
