<?php
/**
 * Script de prueba para la clase Cita
 * Prueba la funcionalidad principal de gestión de citas médicas
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

include_once 'modelo/Cita.php';

echo "===========================================\n";
echo "PRUEBA DE FUNCIONALIDAD - CLASE CITA\n";
echo "===========================================\n\n";

try {
    $cita = new Cita();
    
    if ($cita->acceso === null) {
        echo "❌ ERROR: No se pudo conectar a la base de datos\n";
        echo "   Verifique que el servidor MySQL esté activo\n";
        echo "   y que la base de datos 'biovital' exista\n\n";
        exit(1);
    }
    
    echo "✅ Conexión a base de datos exitosa\n\n";
    
    // ==================== PRUEBA 1: Crear cita ====================
    echo "-------------------------------------------\n";
    echo "PRUEBA 1: Crear cita\n";
    echo "-------------------------------------------\n";
    
    $datos_crear = [
        'id_paciente' => 1,
        'id_medico' => 1,
        'id_consultorio' => 1,
        'id_especialidad' => 1,
        'fecha_cita' => date('Y-m-d', strtotime('+2 days')),
        'hora_inicio' => '10:00',
        'hora_fin' => '10:30',
        'motivo' => 'Consulta general de rutina',
        'estado' => 'programada',
        'tipo_cita' => 'presencial',
        'observaciones' => 'Primera consulta'
    ];
    
    $resultado = $cita->crear($datos_crear);
    
    if ($resultado['success']) {
        echo "✅ Cita creada exitosamente\n";
        echo "   ID de cita: " . $resultado['id'] . "\n";
        $id_cita_creada = $resultado['id'];
    } else {
        echo "❌ Error al crear cita: " . $resultado['message'] . "\n";
        echo "   Esto puede deberse a:\n";
        echo "   - Datos incompletos\n";
        echo "   - Horario no disponible\n";
        echo "   - Error en base de datos\n";
        $id_cita_creada = null;
    }
    echo "\n";
    
    // ==================== PRUEBA 2: Crear cita con datos incompletos ====================
    echo "-------------------------------------------\n";
    echo "PRUEBA 2: Crear cita con datos incompletos\n";
    echo "-------------------------------------------\n";
    
    $datos_incompletos = [
        'id_paciente' => 1,
        'fecha_cita' => date('Y-m-d', strtotime('+3 days')),
        'hora_inicio' => '11:00'
    ];
    
    $resultado = $cita->crear($datos_incompletos);
    
    if (!$resultado['success'] && $resultado['message'] == 'datos_incompletos') {
        echo "✅ Validación correcta: Rechazó datos incompletos\n";
        echo "   Mensaje: " . $resultado['message'] . "\n";
    } else {
        echo "❌ La validación no funcionó correctamente\n";
    }
    echo "\n";
    
    // ==================== PRUEBA 3: Obtener cita por ID ====================
    echo "-------------------------------------------\n";
    echo "PRUEBA 3: Obtener cita por ID\n";
    echo "-------------------------------------------\n";
    
    if ($id_cita_creada) {
        $cita_obtenida = $cita->obtenerPorId($id_cita_creada);
        
        if ($cita_obtenida) {
            echo "✅ Cita obtenida exitosamente\n";
            echo "   ID: " . $cita_obtenida->id_cita . "\n";
            echo "   Fecha: " . $cita_obtenida->fecha_cita . "\n";
            echo "   Hora: " . $cita_obtenida->hora_inicio . " - " . $cita_obtenida->hora_fin . "\n";
            echo "   Estado: " . $cita_obtenida->estado . "\n";
        } else {
            echo "❌ No se pudo obtener la cita\n";
        }
    } else {
        echo "⚠️  Omitida: No se creó una cita en la prueba 1\n";
    }
    echo "\n";
    
    // ==================== PRUEBA 4: Listar citas por paciente ====================
    echo "-------------------------------------------\n";
    echo "PRUEBA 4: Listar citas por paciente\n";
    echo "-------------------------------------------\n";
    
    $citas_paciente = $cita->listarPorPaciente(1);
    
    if (count($citas_paciente) > 0) {
        echo "✅ Se encontraron " . count($citas_paciente) . " citas para el paciente\n";
        foreach (array_slice($citas_paciente, 0, 3) as $c) {
            echo "   - ID: " . $c->id_cita . " | Fecha: " . $c->fecha_cita . " | Estado: " . $c->estado . "\n";
        }
    } else {
        echo "⚠️  No se encontraron citas para el paciente\n";
    }
    echo "\n";
    
    // ==================== PRUEBA 5: Listar citas por médico ====================
    echo "-------------------------------------------\n";
    echo "PRUEBA 5: Listar citas por médico\n";
    echo "-------------------------------------------\n";
    
    $citas_medico = $cita->listarPorMedico(1);
    
    if (count($citas_medico) > 0) {
        echo "✅ Se encontraron " . count($citas_medico) . " citas para el médico\n";
        foreach (array_slice($citas_medico, 0, 3) as $c) {
            echo "   - ID: " . $c->id_cita . " | Fecha: " . $c->fecha_cita . " | Hora: " . $c->hora_inicio . "\n";
        }
    } else {
        echo "⚠️  No se encontraron citas para el médico\n";
    }
    echo "\n";
    
    // ==================== PRUEBA 6: Verificar disponibilidad ====================
    echo "-------------------------------------------\n";
    echo "PRUEBA 6: Verificar disponibilidad\n";
    echo "-------------------------------------------\n";
    
    $fecha_test = date('Y-m-d', strtotime('+5 days'));
    $disponible = $cita->verificarDisponibilidad(1, $fecha_test, '14:00', '14:30');
    
    if ($disponible) {
        echo "✅ Horario disponible para el médico\n";
    } else {
        echo "⚠️  Horario no disponible (ya existe cita)\n";
    }
    echo "\n";
    
    // ==================== PRUEBA 7: Editar cita ====================
    echo "-------------------------------------------\n";
    echo "PRUEBA 7: Editar cita\n";
    echo "-------------------------------------------\n";
    
    if ($id_cita_creada) {
        $datos_editar = [
            'fecha_cita' => date('Y-m-d', strtotime('+3 days')),
            'hora_inicio' => '15:00',
            'hora_fin' => '15:30',
            'motivo' => 'Consulta actualizada',
            'estado' => 'programada',
            'tipo_cita' => 'presencial',
            'observaciones' => 'Observaciones actualizadas'
        ];
        
        $resultado = $cita->editar($id_cita_creada, $datos_editar);
        
        if ($resultado['success']) {
            echo "✅ Cita editada exitosamente\n";
            echo "   Nuevo horario: 15:00 - 15:30\n";
        } else {
            echo "❌ Error al editar cita: " . $resultado['message'] . "\n";
        }
    } else {
        echo "⚠️  Omitida: No se creó una cita en la prueba 1\n";
    }
    echo "\n";
    
    // ==================== PRUEBA 8: Completar cita ====================
    echo "-------------------------------------------\n";
    echo "PRUEBA 8: Completar cita\n";
    echo "-------------------------------------------\n";
    
    if ($id_cita_creada) {
        $resultado = $cita->completar($id_cita_creada);
        
        if ($resultado['success']) {
            echo "✅ Cita completada exitosamente\n";
        } else {
            echo "❌ Error al completar cita: " . $resultado['message'] . "\n";
        }
    } else {
        echo "⚠️  Omitida: No se creó una cita en la prueba 1\n";
    }
    echo "\n";
    
    // ==================== PRUEBA 9: Cancelar cita ====================
    echo "-------------------------------------------\n";
    echo "PRUEBA 9: Cancelar cita\n";
    echo "-------------------------------------------\n";
    
    if ($id_cita_creada) {
        // Primero regresamos a programada para poder cancelar
        $cita->editar($id_cita_creada, [
            'fecha_cita' => date('Y-m-d', strtotime('+4 days')),
            'hora_inicio' => '16:00',
            'hora_fin' => '16:30',
            'motivo' => 'Consulta de prueba',
            'estado' => 'programada',
            'tipo_cita' => 'presencial',
            'observaciones' => ''
        ]);
        
        $resultado = $cita->cancelar($id_cita_creada, 'Paciente solicitó cancelación');
        
        if ($resultado['success']) {
            echo "✅ Cita cancelada exitosamente\n";
        } else {
            echo "❌ Error al cancelar cita: " . $resultado['message'] . "\n";
        }
    } else {
        echo "⚠️  Omitida: No se creó una cita en la prueba 1\n";
    }
    echo "\n";
    
    // ==================== PRUEBA 10: Estadísticas ====================
    echo "-------------------------------------------\n";
    echo "PRUEBA 10: Obtener estadísticas\n";
    echo "-------------------------------------------\n";
    
    $stats = $cita->obtenerEstadisticas();
    
    if (count($stats) > 0) {
        echo "✅ Estadísticas obtenidas:\n";
        foreach ($stats as $key => $value) {
            echo "   - $key: $value\n";
        }
    } else {
        echo "⚠️  No se pudieron obtener estadísticas\n";
    }
    echo "\n";
    
    // ==================== PRUEBA 11: Contar por estado ====================
    echo "-------------------------------------------\n";
    echo "PRUEBA 11: Contar citas por estado\n";
    echo "-------------------------------------------\n";
    
    $total_programadas = $cita->contarPorEstado('programada');
    $total_completadas = $cita->contarPorEstado('completada');
    $total_canceladas = $cita->contarPorEstado('cancelada');
    
    echo "✅ Conteo de citas por estado:\n";
    echo "   - Programadas: $total_programadas\n";
    echo "   - Completadas: $total_completadas\n";
    echo "   - Canceladas: $total_canceladas\n";
    echo "\n";
    
    // ==================== PRUEBA 12: Listar próximas citas ====================
    echo "-------------------------------------------\n";
    echo "PRUEBA 12: Listar próximas citas\n";
    echo "-------------------------------------------\n";
    
    $proximas = $cita->listarProximas(1, 5);
    
    if (count($proximas) > 0) {
        echo "✅ Se encontraron " . count($proximas) . " próximas citas\n";
        foreach ($proximas as $c) {
            echo "   - Fecha: " . $c->fecha_cita . " | Hora: " . $c->hora_inicio . "\n";
        }
    } else {
        echo "⚠️  No se encontraron próximas citas\n";
    }
    echo "\n";
    
    // ==================== RESUMEN ====================
    echo "===========================================\n";
    echo "RESUMEN DE PRUEBAS\n";
    echo "===========================================\n";
    echo "✅ Conexión a base de datos: Funcional\n";
    echo "✅ Método crear: Probado\n";
    echo "✅ Método editar: Probado\n";
    echo "✅ Método cancelar: Probado\n";
    echo "✅ Método completar: Probado\n";
    echo "✅ Método obtenerPorId: Probado\n";
    echo "✅ Método listarPorPaciente: Probado\n";
    echo "✅ Método listarPorMedico: Probado\n";
    echo "✅ Método verificarDisponibilidad: Probado\n";
    echo "✅ Método obtenerEstadisticas: Probado\n";
    echo "✅ Método contarPorEstado: Probado\n";
    echo "✅ Método listarProximas: Probado\n";
    echo "\n";
    echo "La clase Cita está funcionando correctamente.\n";
    
} catch (Exception $e) {
    echo "❌ ERROR GENERAL: " . $e->getMessage() . "\n";
    echo "   Archivo: " . $e->getFile() . "\n";
    echo "   Línea: " . $e->getLine() . "\n";
}
?>
